Send instant notification messages to the user in live.

This technical module allows you to send instant notification messages from the server to the user in live. 
Two kinds of notification are supported.

* Warning: Displayed in a red flying popup div
* Information: Displayed in a light yellow flying popup div