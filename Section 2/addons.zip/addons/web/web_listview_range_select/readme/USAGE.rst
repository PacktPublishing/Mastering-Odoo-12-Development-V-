To use this module, you need to:

#. click a record;
#. hold shift and click another record;
#. you can repeat this operation as many times as you want.
