* `Onestein <https://www.onestein.nl>`_:

  * Dennis Sluijk <d.sluijk@onestein.nl>
  * Andrea Stirpe <a.stirpe@onestein.nl>

* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal <david.vidal@tecnativa.com>
