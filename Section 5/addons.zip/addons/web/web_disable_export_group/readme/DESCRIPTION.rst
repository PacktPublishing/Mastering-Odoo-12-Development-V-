In the standard Odoo the UI option 'Export' that is present in the 'Action' menu
of any list view is always enabled (for every user).

This module makes the option 'Export' enabled only for the users that belong
to the Export Data group.

Admin user can always use the export option.
