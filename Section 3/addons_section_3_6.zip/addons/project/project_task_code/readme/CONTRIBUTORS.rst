* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuarist@avanzosc.es>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Rodrigo Ferreira <rodrigosferreira91@gmail.com>
* Damien Bouvy <dbo@odoo.com>
* Alexey Pelykh <alexey.pelykh@brainbeanapps.com>
