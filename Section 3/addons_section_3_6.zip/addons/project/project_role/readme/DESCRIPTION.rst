This module allows maintaining project roster based on roles. List of roles is
configured at company level.
