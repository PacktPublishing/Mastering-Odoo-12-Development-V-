* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Omar Castiñeira Saavedra <omar@comunitea.com>
* Oliver Dony <@odony>
* Wim Audenaert <Wim.Audenaert@ucamco.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * David Vidal
  * Jairo Llopis
  * Ernesto Tejeda
