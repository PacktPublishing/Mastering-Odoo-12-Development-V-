`1.2.0`
-------

- Added AppBar Color Options

`1.1.0`
-------

- Added Color Customize Options

`1.0.0`
-------

- Init version
