`1.2.0`
-------

- Added In-App Purchases option

`1.1.0`
-------

- Added converter wizard

`1.0.0`
-------

- Init version
