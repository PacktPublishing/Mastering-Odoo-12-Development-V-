To configure the list of roles available go to
*Project > Configuration > Project Roles*
and create project roles according to your business processes.

Project assignments can be configured from project editing screen via
*Assignments* page as well as via *Project > Assignments*.
