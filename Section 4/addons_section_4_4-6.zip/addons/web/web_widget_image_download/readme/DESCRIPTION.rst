This module was written to extend the functionality of the image widget and
allows to download it.
