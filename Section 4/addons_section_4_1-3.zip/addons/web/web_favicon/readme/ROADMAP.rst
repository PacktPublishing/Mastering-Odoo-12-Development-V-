* Allow to upload some big icon (preferrably SVG or the like) and generate
  all the icons from it
* Generate icons suitable for mobile devices and web apps (see /static/src/img/
  folder inside the module for a sample of the possible current formats.
* Put the icon definition at system level, not at company level. It doesn't
  make sense (as the icon is cached) to have a different icon per company.
