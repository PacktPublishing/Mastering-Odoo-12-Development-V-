Whenever on a float or monetary input field pressing numpad dot produces the
proper decimal separator for the active localization.
